# Dlib compiled wheels for Python 3.7, 3.8, 3.9 for Windows 10 X64
Dlib compiled binary (.whl) for python 3.7, 3.8, 3.9 for windows x64

After wasting a lot of time to get these files, I compiled them myself.

1- Download the file you need

2- copy it in the root folder of ypur python distribuition

3- open a cmd shell in the your root python folder 

example:
```
cd c:\python37
```

4- Install dlib true PIP

### python 3.7
```
python -m pip install dlib-19.22.99-cp37-cp37m-win_amd64.whl 
```
### python 3.8
```
python -m pip install dlib-19.22.99-cp38-cp38m-win_amd64.whl
```
### python 3.9
```
python -m pip install dlib-19.22.99-cp39-cp39m-win_amd64.whl
```
That's it

